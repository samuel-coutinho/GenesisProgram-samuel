var commom = function() {	
	$(".form-group").hide();										
	$("#numFloors").show();
	$("#numBasements").show();
						//$("#show").text( "t" );
};

					//var showForm - function()

$(document).ready(function(){
	$(".form-group").hide();									
});

$("#type-answer").change(function(){					
	var selectedAnswer = $(this).find(':selected').text();
						/*$("#show").text( selectedAnswer );*/									
	if (selectedAnswer === "Select") {
	    $(".form-group").hide();
	} else if (selectedAnswer === "Residential") {
		commom();													
		$("#Apartments").show();							
	} else if (selectedAnswer === "Commercial") {
		commom();												
		$("#numBusinesses").show();
		$("#numParking").show();
		$("#numCages").show();
    } else if (selectedAnswer === "Corporate") {
        commom();													
        $("#numCompanies").show();
        $("#numParking").show();
        $("#numOccupants").show();
    } else if (selectedAnswer === "Hybrid") {
        commom();													
        $("#numBusinesses").show();
        $("#numParking").show();
        $("#numOccupants").show();
        $("#numHours").show();
    }
});