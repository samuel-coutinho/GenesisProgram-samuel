// Variables
var numApartments = 0;
var numFloors1 = 0;
var numBasements = 0;
var numShafts = 0;
var numElevators = 0;
var numColumns = 0;
var numOccupants = 0;
var totalNumberOccupants = 0;


// Begin

$(document).ready(function()	{
	$(".form-group").hide();									
});

$("#type-answer").change(function(){	
					
	var selectedAnswer = $(this).find(':selected').text();
						/*$("#show").text( selectedAnswer );*/									
	if (selectedAnswer === "Select") {
	    $(".form-group").hide();
	} else if (selectedAnswer === "Residential") {		
		commom();													
		$("#numApartments").show();	
		$("#numFloors1").show();	
        calcRes();						
	} else if (selectedAnswer === "Commercial") {		
		commom();													
		$("#numBusinesses").show();
		$("#numParking").show();
		$("#numCages").show();
		$("#numFloors1").show();		
		calcCom();
    } else if (selectedAnswer === "Corporate") {
        commom();													
        $("#numCompanies").show();
        $("#numParking").show();
		$("#numOccupants").show();
		$("#numFloors2").show();
		calcCorpHybr();	
    } else if (selectedAnswer === "Hybrid") {
        commom();													
        $("#numBusinesses").show();
        $("#numParking").show();
        $("#numOccupants").show();
		$("#numHours").show();
		$("#numFloors2").show();
		calcCorpHybr();	
    }   
});


// Funcions

var cleanValues = function()	{
	$("#form-group").each (function(){
		this.reset();
	});
	numShafts = 0;
	numColumns = 0;
	//$("#t").hide();
}

var commom = function() {	
	$("#fields")[0].reset();
	$(".form-group").hide();									
	
	$("#numBasements").show();
	//cleanValues();
}

var calcRes = function()	{        
    $("#fields").change(function(){ 		
		event.preventDefault();         		
	    numApartments = $("#input_apartments").val();
		numFloors1 = $("#input_floors").val();		
		//var radioValue = $("input[name='radio-btn']:checked").val();		
		numShafts = Math.ceil((numApartments /  numFloors1) / 6);
		numColumns = Math.ceil(numFloors / 20);
		numElevators = numShafts * numColumns;
		showResults();				
    });
};

var calcCom = function()	{        
    $("#fields").change(function(){ 
		event.preventDefault();         		
	    numShafts = $("#input_cages").val();		
		showResults();
    });
};

var calcCorpHybr = function() {
	$("#fields").change(function(){ 
		event.preventDefault(); 
		var numFloors2 = $("#input_floors2").val();		
		numOccupants = $("#input_occupants").val();
		totalNumberOccupants = numOccupants * numFloors2;
		numColumns = Math.ceil(numFloors2 / 20);
		numShafts = Math.ceil(totalNumberOccupants / 1000);
		var numCages = Math.ceil(numShafts / numColumns);
		numElevators = numCages * numColumns;
		showResults();		
	});
};

var showResults = function()	{
	$("#showColumns").text( "Number of columns = " + numColumns);
	$("#showElevators").text( "Number of shafts = " + numElevators);
}
