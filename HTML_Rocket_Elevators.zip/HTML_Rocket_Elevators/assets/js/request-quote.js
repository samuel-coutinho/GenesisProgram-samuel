var commom = function() {	
	$(".form-group").hide();										
	$("#numFloors").show();
	$("#numBasements").show();
						//$("#show").text( "t" );
};

					//var showForm - function()

$(document).ready(function()	{
	$(".form-group").hide();									
});

$( "input" )

var calcRes = function()	{        
    $("#fields").submit(function(){ 
		event.preventDefault();         		
	    var numApartments = $("#input_apartments").val();
		var numFloors = $("#input_floors").val();
		var numBasements = $("#input_basements").val();
		numFloors -= numBasements;
		var numShafts = 	Math.ceil((numApartments /  numFloors) / 6);
		var numColumns = Math.ceil(numFloors / 20);
		numShafts *= numColumns;
		$("#t").text( numShafts );
    });
};


var calcCom = function()	{        
    $("#fields").submit(function(){ 
		event.preventDefault();         		
	    var numCages = $("#input_cages").val();		
		$("#t").text( numCages );
    });
};


$("#type-answer").change(function(){

	$("#form-group").each (function(){
		this.reset();
	  });
					
	var selectedAnswer = $(this).find(':selected').text();
						/*$("#show").text( selectedAnswer );*/									
	if (selectedAnswer === "Select") {
	    $(".form-group").hide();
	} else if (selectedAnswer === "Residential") {
		
		commom();													
		$("#numApartments").show();		
        calcRes();						
	} else if (selectedAnswer === "Commercial") {
		
		commom();													
		$("#numBusinesses").show();
		$("#numParking").show();
		$("#numCages").show();		
		calcCom();
    } else if (selectedAnswer === "Corporate") {
        commom();													
        $("#numCompanies").show();
        $("#numParking").show();
		$("#numOccupants").show();
	
    } else if (selectedAnswer === "Hybrid") {
        commom();													
        $("#numBusinesses").show();
        $("#numParking").show();
        $("#numOccupants").show();
		$("#numHours").show();
		
    }   

});



